<?php
session_start();
if (!isset($_SESSION['acceso']) || $_SESSION['acceso'] !== true) {
    header('Location: crud/login.php');
    exit;
}
include('crud/conexion.php');
ob_start();
?>

<?php include("css/header.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CRUD de Empleados</title>
    <link rel="stylesheet" href="css/administracion.css">
</head>
<body>
    <h1>Gestión de Empleados</h1>
<a class="cerrar-sesion" href="crud/logout.php">🔓 Cerrar sesión</a>
<a class="agregar" href="crud/agregar.php">➕ Agregar Empleado</a>


    <h2>Lista de Empleados</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Documento</th>
                <th>Nombre</th>
                <th>Sexo</th>
                <th>Domicilio</th>
                <th>Fecha Ingreso</th>
                <th>Fecha Nacimiento</th>
                <th>Sueldo Básico</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT * FROM empleado ORDER BY nombre ASC";
            $resultado = $conexion->query($query);
            while ($fila = $resultado->fetch_assoc()):
            ?>
            <tr>
                <td><?= $fila['documento'] ?></td>
                <td><?= $fila['nombre'] ?></td>
                <td><?= $fila['sexo'] == 'f' ? 'Femenino' : 'Masculino' ?></td>
                <td><?= $fila['domicilio'] ?></td>
                <td><?= $fila['fechaingreso'] ?></td>
                <td><?= $fila['fechanacimiento'] ?></td>
                <td><?= number_format($fila['sueldobasico'], 2) ?></td>
                <td>
                    <a class="btn" href="crud/editar.php?documento=<?= $fila['documento'] ?>">✏️ Editar</a>
                    <a class="btn-eliminar" href="#" data-doc="<?= $fila['documento'] ?>">❌ Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Consultas Generales</h2>
    <select id="consultaSelector">
        <option value="">-- Selecciona una consulta --</option>
        <option value="consulta1">1. Empleados por sexo</option>
        <option value="consulta2">2. Aumento del 10%</option>
        <option value="consulta3">3. Total de la nómina por sexo</option>
        <option value="consulta4">4. Sueldo mayor al salario mínimo</option>
    </select>

    <div id="resultadoConsulta"></div>

    <div id="modal-confirmacion" class="modal">
        <div class="modal-contenido">
            <p>¿Estás seguro de que deseas eliminar este empleado?</p>
            <div class="modal-acciones">
                <a href="#" id="btn-confirmar" class="btn-confirmar">Aceptar</a>
                <button id="btn-cancelar" class="btn-cancelar">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('consultaSelector').addEventListener('change', function () {
        const seleccion = this.value;
        const resultadoDiv = document.getElementById('resultadoConsulta');
        resultadoDiv.innerHTML = 'Cargando...';

        fetch('', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'consulta=' + encodeURIComponent(seleccion)
        })
        .then(res => res.text())
        .then(html => {
            resultadoDiv.innerHTML = html;
        })
        .catch(err => {
            resultadoDiv.innerHTML = '<p style="color:red;">Error al cargar consulta.</p>';
        });
    });

    document.querySelectorAll('.btn-eliminar').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const doc = this.getAttribute('data-doc');
            const enlace = document.getElementById('btn-confirmar');
            enlace.href = 'crud/eliminar.php?documento=' + doc;
            document.getElementById('modal-confirmacion').style.display = 'flex';
        });
    });

    document.getElementById('btn-cancelar').addEventListener('click', function () {
        document.getElementById('modal-confirmacion').style.display = 'none';
    });
    </script>

    <?php
    if (isset($_POST['consulta'])) {
        ob_clean(); 

        switch ($_POST['consulta']) {
            case 'consulta1':
                $res = $conexion->query("SELECT sexo, COUNT(*) AS cantidad FROM empleado GROUP BY sexo");
                echo "<h3>Empleados por sexo</h3>";
                while ($row = $res->fetch_assoc()) {
                    echo "<p>" . ($row['sexo'] == 'f' ? "Femenino" : "Masculino") . ": {$row['cantidad']}</p>";
                }
                break;

            case 'consulta2':
                $res = $conexion->query("SELECT nombre, sueldobasico FROM empleado ORDER BY nombre ASC");
                echo "<h3>Simulación de aumento del 10%</h3>";
                echo "<table border='1'><thead><tr><th>Nombre</th><th>Actual</th><th>Con Aumento</th></tr></thead><tbody>";
                while ($row = $res->fetch_assoc()) {
                    $nuevo = $row['sueldobasico'] * 1.10;
                    echo "<tr><td>{$row['nombre']}</td><td>" . number_format($row['sueldobasico'], 2) . "</td><td>" . number_format($nuevo, 2) . "</td></tr>";
                }
                echo "</tbody></table>";
                break;

            case 'consulta3':
                $sexos = ['f' => 'Femenino', 'm' => 'Masculino'];
                foreach ($sexos as $codigo => $etiqueta) {
                    echo "<h3 style='margin-top:20px;'>Nómina: $etiqueta</h3>";
                    $res = $conexion->query("SELECT nombre, sueldobasico FROM empleado WHERE sexo = '$codigo' ORDER BY nombre ASC");

                    if ($res->num_rows > 0) {
                        echo "<table border='1' style='margin-bottom:20px;'><thead><tr><th>Nombre</th><th>Sueldo Básico</th></tr></thead><tbody>";
                        $total = 0;
                        while ($row = $res->fetch_assoc()) {
                            $sueldo = number_format($row['sueldobasico'], 2);
                            echo "<tr><td>{$row['nombre']}</td><td>$$sueldo</td></tr>";
                            $total += $row['sueldobasico'];
                        }
                        echo "<tr><th>Total</th><th>$" . number_format($total, 2) . "</th></tr>";
                        echo "</tbody></table>";
                    } else {
                        echo "<p>No hay empleados registrados para este sexo.</p>";
                    }
                }
                break;

           case 'consulta4':
                $res = $conexion->query("SELECT nombre, sueldobasico FROM empleado WHERE sueldobasico > 400 ORDER BY sueldobasico DESC");
                echo "<h3>Empleados con sueldo mayor al salario mínimo</h3>";

        if ($res->num_rows > 0) {
            echo "<table border='1'><thead><tr><th>Nombre</th><th>Sueldo</th></tr></thead><tbody>";
            while ($row = $res->fetch_assoc()) {
                 echo "<tr><td>{$row['nombre']}</td><td>$" . number_format($row['sueldobasico'], 2) . "</td></tr>";
        }
            echo "</tbody></table>";
        } else {
            echo "<p>No hay empleados con sueldo mayor al salario mínimo.</p>";
    }
            break;

        }

        exit;
    }
    ?>
</body>
</html>
