<?php include('conexion.php'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Empleado</title>
    <link rel="stylesheet" href="../css/agregar.css">
</head>
<body>
    <form method="POST" action="">
        <h1>Agregar Nuevo Empleado</h1>

        <label>Documento:</label>
        <input type="text" name="documento" pattern="\d+" title="Solo números" required><br>

        <label>Nombre:</label>
        <input type="text" name="nombre" pattern="[A-Za-zÁÉÍÓÚáéíóúñÑ ]+" title="Solo letras" required><br>

        <label>Sexo:</label>
        <select name="sexo" required>
            <option value="">--Seleccione--</option>
            <option value="m">Masculino</option>
            <option value="f">Femenino</option>
        </select><br>

        <label>Domicilio:</label>
        <input type="text" name="domicilio" required><br>

        <label>Fecha Ingreso:</label>
        <input type="date" name="fechaingreso" required><br>

        <label>Fecha Nacimiento:</label>
        <input type="date" name="fechanacimiento" required><br>

        <label>Sueldo Básico:</label>
        <input type="number" step="0.01" name="sueldobasico" min="0" required><br>

        <button type="submit" name="guardar">Guardar</button>
        <button type="button" onclick="window.location.href='../administracion.php'">Volver</button>
    </form>

    <?php
    if (isset($_POST['guardar'])) {
        // Validación en PHP
        $doc = $_POST['documento'];
        $nombre = $_POST['nombre'];
        $sexo = $_POST['sexo'];
        $dom = $_POST['domicilio'];
        $ing = $_POST['fechaingreso'];
        $nac = $_POST['fechanacimiento'];
        $sueldo = $_POST['sueldobasico'];

        // Validaciones adicionales
        if (!preg_match('/^\d+$/', $doc)) {
            echo "<p style='color:red;'>Documento debe contener solo números.</p>";
        } elseif (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúñÑ ]+$/', $nombre)) {
            echo "<p style='color:red;'>Nombre inválido.</p>";
        } elseif ($sueldo < 0) {
            echo "<p style='color:red;'>El sueldo no puede ser negativo.</p>";
        } else {
            // Inserción segura con sentencia preparada
            $stmt = $conexion->prepare("INSERT INTO empleado (documento, nombre, sexo, domicilio, fechaingreso, fechanacimiento, sueldobasico) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssd", $doc, $nombre, $sexo, $dom, $ing, $nac, $sueldo);

            if ($stmt->execute()) {
                echo "<p style='color:green;'>Empleado agregado correctamente.</p>";
                echo "<a href='../administracion.php'>Volver</a>";
            } else {
                echo "<p style='color:red;'>Error: {$stmt->error}</p>";
            }
            $stmt->close();
        }
    }
    ?>
</body>
</html>
