<?php include('conexion.php'); ?>
<?php
if (!isset($_GET['documento'])) {
    die("Documento no proporcionado.");
}

$documento = $_GET['documento'];

// Evitamos inyección y verificamos si existe
$stmt = $conexion->prepare("SELECT * FROM empleado WHERE documento = ?");
$stmt->bind_param("s", $documento);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    die("Empleado no encontrado.");
}
$empleado = $res->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Empleado</title>
    <link rel="stylesheet" href="../css/agregar.css">
</head>
<body>
    <form method="POST" action="">
        <h1>Editar Empleado</h1>

        <label>Nombre:</label>
        <input type="text" name="nombre" pattern="[A-Za-zÁÉÍÓÚáéíóúñÑ ]+" title="Solo letras" value="<?= htmlspecialchars($empleado['nombre']) ?>" required><br>

        <label>Sexo:</label>
        <select name="sexo" required>
            <option value="m" <?= $empleado['sexo'] == 'm' ? 'selected' : '' ?>>Masculino</option>
            <option value="f" <?= $empleado['sexo'] == 'f' ? 'selected' : '' ?>>Femenino</option>
        </select><br>

        <label>Domicilio:</label>
        <input type="text" name="domicilio" value="<?= htmlspecialchars($empleado['domicilio']) ?>" required><br>

        <label>Fecha Ingreso:</label>
        <input type="date" name="fechaingreso" value="<?= $empleado['fechaingreso'] ?>" required><br>

        <label>Fecha Nacimiento:</label>
        <input type="date" name="fechanacimiento" value="<?= $empleado['fechanacimiento'] ?>" required><br>

        <label>Sueldo Básico:</label>
        <input type="number" step="0.01" name="sueldobasico" min="0" value="<?= $empleado['sueldobasico'] ?>" required><br>

        <button type="submit" name="actualizar">Actualizar</button>
        <button type="button" onclick="window.location.href='../administracion.php'">Volver</button>
    </form>

    <?php
    if (isset($_POST['actualizar'])) {
        $nombre = $_POST['nombre'];
        $sexo = $_POST['sexo'];
        $dom = $_POST['domicilio'];
        $ing = $_POST['fechaingreso'];
        $nac = $_POST['fechanacimiento'];
        $sueldo = $_POST['sueldobasico'];

        // Validaciones básicas en PHP
        if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúñÑ ]+$/', $nombre)) {
            echo "<p style='color:red;'>Nombre inválido.</p>";
        } elseif ($sueldo < 0) {
            echo "<p style='color:red;'>El sueldo no puede ser negativo.</p>";
        } else {
            // Usamos sentencia preparada
            $stmt = $conexion->prepare("UPDATE empleado SET nombre=?, sexo=?, domicilio=?, fechaingreso=?, fechanacimiento=?, sueldobasico=? WHERE documento=?");
            $stmt->bind_param("ssssssd", $nombre, $sexo, $dom, $ing, $nac, $sueldo, $documento);

            if ($stmt->execute()) {
                echo "<p style='color:green;'>Empleado actualizado correctamente.</p>";
                echo "<a href='../administracion.php'>Volver</a>";
            } else {
                echo "<p style='color:red;'>Error: {$stmt->error}</p>";
            }
            $stmt->close();
        }
    }
    ?>
</body>
</html>
