<?php
include('conexion.php');

$message = '';
$message_color = 'green';
$eliminado = false;

if (isset($_GET['documento'])) {
    $documento = $_GET['documento'];
    $sql = "DELETE FROM empleado WHERE documento = '$documento'";

    if ($conexion->query($sql)) {
        $message = "Empleado eliminado correctamente.";
        $eliminado = true;
    } else {
        $message = "Error al eliminar: " . $conexion->error;
        $message_color = 'red';
    }
} else {
    $message = "Documento no especificado.";
    $message_color = 'red';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Empleado</title>
    <link rel="stylesheet" href="../css/eliminar.css">
</head>
<body>
    <div class="mensaje-container">
        <div class="mensaje-box" style="border-left: 6px solid <?php echo $message_color; ?>">
            <h2 style="color: <?php echo $message_color; ?>"><?php echo $message; ?></h2>
            <a href="../administracion.php" class="btn-volver">Volver</a>
        </div>
    </div>
</body>
</html>
