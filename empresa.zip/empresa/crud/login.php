<?php
session_start();

$clave_correcta = 'clave123'; // clave en texto plano

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clave_ingresada = $_POST['clave'] ?? '';

    if ($clave_ingresada === $clave_correcta) {
        $_SESSION['acceso'] = true;
        header('Location: ../administracion.php');
        exit;
    } else {
        $error = "Clave incorrecta.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso Administración</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <h2>Ingrese su clave</h2>

    <form method="POST">
        <input type="password" name="clave" class="input" placeholder="Enter your password!" required><br>
        <button type="submit" class="button">Ingresar</button>
    </form>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>
</body>
</html>
