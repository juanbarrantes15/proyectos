<?php
$conexion = new mysqli("localhost", "root", "", "quantara");
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$mesSeleccionado = isset($_POST['mes']) ? intval($_POST['mes']) : null;

$sql = "SELECT documento, nombre, sexo, fechanacimiento FROM empleado ORDER BY MONTH(fechanacimiento), DAY(fechanacimiento)";
$resultado = $conexion->query($sql);

$empleados = [];
$rosas = 0;
$corbatas = 0;

while ($fila = $resultado->fetch_assoc()) {
    $empleados[] = $fila;

    if ($mesSeleccionado !== null) {
        $mesCumple = date('n', strtotime($fila['fechanacimiento']));
        if ($mesCumple == $mesSeleccionado) {
            if (strtoupper($fila['sexo']) === 'F') {
                $rosas++;
            } elseif (strtoupper($fila['sexo']) === 'M') {
                $corbatas++;
            }
        }
    }
}
?>
<?php include("css/header.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cumpleaños de Empleados</title>
    <link rel="stylesheet" href="css/cumpleanos.css">
</head>
<body>
    <div id="contenedor-globos"></div>

    <h1>Cumpleaños de Empleados</h1>

    <main>
        <div class="consulta-form">
            <form method="post">
                <label for="mes">Selecciona el mes:</label>
                <?php
                    $meses = [
                        1 => "Enero", 2 => "Febrero", 3 => "Marzo", 4 => "Abril",
                        5 => "Mayo", 6 => "Junio", 7 => "Julio", 8 => "Agosto",
                        9 => "Septiembre", 10 => "Octubre", 11 => "Noviembre", 12 => "Diciembre"
                    ];
                ?>

                <select name="mes" id="mes">
                    <?php
                    foreach ($meses as $numero => $nombre) {
                        $selected = ($numero == $mesSeleccionado) ? "selected" : "";
                        echo "<option value=\"$numero\" $selected>$nombre</option>";
                    }
                    ?>
                </select>

                <button type="submit">Consultar regalos</button>
            </form>

            <?php if ($mesSeleccionado !== null): ?>
                <div class="regalos">
                    <h3>Regalos para el mes de <?= $meses[$mesSeleccionado] ?>:</h3>
                    <p><strong><?= $rosas ?></strong> ramos de rosas (para mujeres)</p>
                    <p><strong><?= $corbatas ?></strong> corbatas (para hombres)</p>
                </div>
            <?php endif; ?>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Documento</th>
                    <th>Nombre</th>
                    <th>Fecha de Nacimiento</th>
                    <th>Sexo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($empleados as $empleado): ?>
                    <tr>
                        <td><?= htmlspecialchars($empleado['documento']) ?></td>
                        <td><?= htmlspecialchars($empleado['nombre']) ?></td>
                        <td><?= date("d/m/Y", strtotime($empleado['fechanacimiento'])) ?></td>
                        <td><?= strtoupper($empleado['sexo']) === 'F' ? 'Femenino' : 'Masculino' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>

    <script>
        const contenedor = document.getElementById("contenedor-globos");

        function crearGlobo() {
            const globo = document.createElement("div");
            globo.classList.add("globo");

            globo.style.left = Math.random() * window.innerWidth + "px";

            const colores = ["red", "blue", "green", "yellow", "purple", "orange"];
            globo.style.backgroundColor = colores[Math.floor(Math.random() * colores.length)];

            contenedor.appendChild(globo);

            setTimeout(() => {
                globo.remove();
            }, 8000);
        }

        window.onload = () => {
            for (let i = 0; i < 30; i++) {
                setTimeout(crearGlobo, i * 300);
            }
        };
    </script>
</body>
</html>

<?php
$conexion->close();
?>
