<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Quantara Corp</title>
    <link rel="stylesheet" href="css/index.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="logo">
            <img src="imagenes/quantara.jpg" alt="Quantara Corp">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="cumpleanos.php">Cumpleaños</a></li>
                <li><a href="administracion.php">Administración</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="contenido">
            <div class="informacion">
                <h2>Objetivos de la Empresa</h2>
                <p><strong>Misión:</strong> Impulsar la transformación digital de empresas y gobiernos a través de soluciones tecnológicas avanzadas, sostenibles y seguras.</p>
                <p><strong>Visión:</strong> Ser un referente global en innovación tecnológica, destacando por nuestro compromiso con la excelencia, la ética y el impacto social.</p>
                <button class="boton-blanco" onclick="mostrarInfo()">Conoce más</button>
                <div id="infoExtra" style="display: none; margin-top: 1rem;">
                    <p>Quantara Corp se especializa en ciberseguridad, infraestructura en la nube, inteligencia artificial y servicios de automatización para clientes del sector público y privado en América Latina.</p>
                </div>
                <script>
                    function mostrarInfo() {
                        var info = document.getElementById("infoExtra");
                        info.style.display = (info.style.display === "none") ? "block" : "none";
                    }
                </script>
            </div>
            <div class="imagen">
                <img src="imagenes/quantara.jpg" alt="logo">
            </div>
        </section>
    </main>
</body>
</html>


